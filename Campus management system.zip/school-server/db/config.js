module.exports = {
    // dbs: 'mongodb://139.159.253.110:27017/test1'
    dbs: 'mongodb+srv://admin:admin@cluster0.axndh.mongodb.net/test0?retryWrites=true&w=majority'
}